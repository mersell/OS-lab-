#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

/* Proses kimlik bilgilerini ekrana yazdırır */
void log_info() {
    printf("[BİLGİ] PID: %d, PPID: %d\n", getpid(), getppid());
}

int main(int argc, char *argv[]) {
    /* Komut satırından derinlik argümanı gelip gelmediğini kontrol eder */
    if (argc < 2) {
        printf("Hata: Derinlik degeri girmelisin!");
        return 1;
    }

    /* Girilen karakter değerini tam sayıya çevirir */
    int depth_limit = atoi(argv[1]);

    /* Derinlik değerinin en az 1 olması gerektiğini denetler */
    if (depth_limit < 1) {
        printf("Hata: Derinlik degeri en az 1 olmalidir!\n");
        return 1;
    }

    /* Ebeveyn proses hazırlıkları: Klasör oluşturma ve tarih bilgisi yazma */
    system("mkdir -p 211116_uyg2A_logs"); 
    system("date > logs/211116_uyg2A.log_all.log");
    log_info();

    /* İlk dal: Çocuk1  oluşturuluyor */
    pid_t c1 = fork();
    if (c1 == 0) {
        /* Çocuk1 döngü ile girilen derinlik kadar aşağı uzayacak */
        for (int i = 1; i <= depth_limit; i++) {
            log_info();
            
            /* Eğer hedeflenen derinliğe ulaşılmadıysa yeni alt proses oluşturur */
            if (i < depth_limit) {
                pid_t next_child = fork();
                if (next_child > 0) {
                    /* Bir alt prosesi yaratan üst proses 1 sn bekler ve görevini bitirir */
                    sleep(1); 
                    exit(0);
                }
                /* Alt proses döngünün bir sonraki adımına geçer */
            } else {
                /* Zincirin en sonundaki proses 2 sn bekler ve biter */
                sleep(2);
                exit(0);
            }
        }
    } else {
        /* İkinci dal: Çocuk2 (Sabit kol) oluşturuluyor */
        pid_t c2 = fork();
        if (c2 == 0) {
            log_info();
            /* Çocuk2 her zaman 2 sn bekler ve biter */
            sleep(2);
            exit(0);
        }

        /* Ebeveyn proses, çocukların oluşması için 1 sn bekler */
        sleep(1);
        
        /* Proses ağacını log dosyasına basmak için sistem komutu hazırlar */
        char tree_cmd[128];
        sprintf(tree_cmd, "pstree -sg %d >> logs/211116_uyg2A.log_all.log", getpid());
        system(tree_cmd);
        
        printf(" parent tamamladi.\n");
    }

    return 0;
}
