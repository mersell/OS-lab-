#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include <time.h> // usleep() kullanimi icin gerekli 


struct multiplePrintData {
    pthread_t id;
    int threadid;
    char *printText;
    double waitDuration;
};


void printCharMultipleTimes(char *prTxt, double seconds)
{
    int count = 0;
    while(true)
    {
        count++;
        fflush(stdout);                         //anlik degisimler icin buffer temizlenmesi
        printf("%s", prTxt);                   
        usleep((int)(seconds*1000000));         //seconds=1 icin yaklasik 1 saniye bekler 
    }
}


/**
 * Thread'in doğrudan bağlandığı ara fonksiyon. 
 * Bu fonksiyon yukarıdaki  fonksiyonu çağırır.*/
void* thread_runner(void* arg) {
    struct multiplePrintData *data = (struct multiplePrintData *)arg;
    //  fonksiyonu çağırıyoruz:
    printCharMultipleTimes(data->printText, data->waitDuration);
    return NULL;
}

int main(int argc, char *argv[]) {
    // 1. Terminal parametrelerinin alınması 
    if (argc < 3) {
        printf("Kullanim: ./211116_uyg3A <toplam_sure> <thread_sayisi> <metin1> <sure1> ...\n");
        return 1;
    }

    int total_duration = atoi(argv[1]); 
    int n = atoi(argv[2]);              

    // Dinamik thread yönetimi
    struct multiplePrintData *thread_data = malloc(sizeof(struct multiplePrintData) * n);

    int arg_index = 3;
    for (int i = 0; i < n; i++) {
        thread_data[i].threadid = i;
        thread_data[i].printText = argv[arg_index++];
        // Milisaniyeyi saniyeye çeviriyoruz
        thread_data[i].waitDuration = atof(argv[arg_index++]) / 1000.0; 

        // Thread'i ara fonksiyon (thread_runner) üzerinden başlatıyoruz 
        pthread_create(&thread_data[i].id, NULL, thread_runner, &thread_data[i]);
    }

    // Toplam çalışma süresi kadar bekleme
    usleep(total_duration * 1000);

    printf("\nBelirlenen sure doldu. Program sonlandiriliyor.\n");
    
    free(thread_data);
 
    return 0;
}