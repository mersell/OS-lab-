#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>

/* Global degiskenler */
pid_t child_pid;
int terminal_action = 0; /* 0: Yasam, 1: Olum */

/* Eski sinyal ayarlarini saklamak icin handler dizisi */
void (*oldHandlers[6])(int);

/* Sinyal isleyicisi */
void signal_handler(int sig) {
    if (sig == SIGALRM) {
        /* Alarm caldiginda kader belirlenir */
        if (terminal_action == 1) {
            printf("\n[PARENT] Karar: Olum. Cocuk sonlandiriliyor...\n");
            kill(child_pid, SIGKILL); /* Cocugu zorla kapat */
        } else {
            printf("\n[PARENT] Karar: Yasam. Cocugun bitmesi bekleniyor...\n");
            wait(NULL); /* Cocugu bekle */
        }
        
        /* TUM KORUMALARI KALDIR: Sinyalleri eski haline dondur */
        signal(SIGINT, oldHandlers[0]);
        signal(SIGTSTP, oldHandlers[1]);
        signal(SIGQUIT, oldHandlers[2]);
        signal(SIGTERM, oldHandlers[3]);
        signal(SIGCONT, oldHandlers[4]);
        
        printf("[PARENT] Tum korumalar kalkti. 5 saniye beklemedeyim...\n");
        printf("[PARENT] Artik Ctrl+C veya diger sinyaller programi kapatir.\n");
        
        sleep(5); 
        printf("[PARENT] Bekleme bitti. Program dogal akisinda kapaniyor.\n");
        exit(0);
    } else {
        /* Alarm oncesi gelen tum sinyalleri yakalar ve yok sayar */
        printf("\n[SYSTEM] Sinyal %d yakalandi. Alarm calmadan kapanma yapilmaz!\n", sig);
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Hata: Saniye degeri girmelisiniz.\n");
        return 1;
    }

    int pipe_fd[2];
    if (pipe(pipe_fd) == -1) return 1; /* Pipe ac */

    int timer_val = atoi(argv[1]);
    char outgoing_msg[100];

    /* 5 Farkli Sinyali handler'a bagla ve eski hallerini sakla */
    oldHandlers[0] = signal(SIGINT, signal_handler);  /* Ctrl+C */
    oldHandlers[1] = signal(SIGTSTP, signal_handler); /* Ctrl+Z */
    oldHandlers[2] = signal(SIGQUIT, signal_handler); /* Ctrl+\ */
    oldHandlers[3] = signal(SIGTERM, signal_handler); /* Kill komutu */
    oldHandlers[4] = signal(SIGCONT, signal_handler); /* Devam sinyali */
    
    /* Alarm sinyalini ayrica bagla */
    signal(SIGALRM, signal_handler); 

    child_pid = fork(); /* Sureci bol */

    if (child_pid < 0) return 1;

    if (child_pid == 0) { 
        /* COCUK SUREC */
        close(pipe_fd[1]);
        char incoming_msg[100];
        
        read(pipe_fd[0], incoming_msg, sizeof(incoming_msg)); /* Mesaji al */
        printf("[CHILD] Ebeveynden gelen mesaj: %s\n", incoming_msg);
        
        sleep(5); /* 5 saniye kaderini bekle */
        close(pipe_fd[0]);
        exit(0);
    } 
    else { 
        /* EBEVEYN SUREC */
        close(pipe_fd[0]);

        if (timer_val % 2 == 0) {
            strcpy(outgoing_msg, "I'll try to kill you when your time is up!");
            terminal_action = 1; /* Olum */
        } else {
            strcpy(outgoing_msg, "You'll live your life!");
            terminal_action = 0; /* Yasam */
        }

        write(pipe_fd[1], outgoing_msg, strlen(outgoing_msg) + 1); /* Mesaj gonder */
        alarm(timer_val); /* Geri sayimi baslat */
        
        close(pipe_fd[1]);
        while(1) pause(); /* Sinyal bekle */
    }
    return 0;
}