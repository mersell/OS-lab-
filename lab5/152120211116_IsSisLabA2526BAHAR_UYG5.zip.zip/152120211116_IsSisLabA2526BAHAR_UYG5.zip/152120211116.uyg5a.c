#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>   /* sem_t kullanmayi tercih ederseniz */
#include <errno.h>


#define TOPLAM_OGE 11
#define THREAD_SAYI   4

sem_t sem_cpu, sem_pompa, sem_sata, sem_ram , sem_ekran, sem_son;

static int             g_sira          = 0;
static pthread_mutex_t g_yazdir_mutex  = PTHREAD_MUTEX_INITIALIZER;


static void oge_yazdir(const char *thread_adi, const char *oge_adi)
{
    pthread_mutex_lock(&g_yazdir_mutex);

    g_sira++;
    int sira  = g_sira;
    int kalan = TOPLAM_OGE - sira;

    if (sira == 1) {
        printf("0.\t--> Haydi baslayalim...\n");
    }

    printf("%2d. (%s) %s", sira, thread_adi, oge_adi);

    if (sira == TOPLAM_OGE) {
        printf("\t--> Hazirim...");
    } else if (sira * 2 > TOPLAM_OGE) {
        /* Sira > TOPLAM_OGE/2 olunca, yani yarisindan fazlasi tamamlaninca */
        printf("\t--> Kalan oge sayisi: %d", kalan);
    }

    printf("\n");
    fflush(stdout);

    pthread_mutex_unlock(&g_yazdir_mutex);
}

static void thread_tamam(const char *thread_adi)
{
    pthread_mutex_lock(&g_yazdir_mutex);
    printf("    --> %s tamam\n", thread_adi);
    fflush(stdout);
    pthread_mutex_unlock(&g_yazdir_mutex);
}


static void *islemci_thread(void *arg)
{
    (void)arg;

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("islemci", "Cpu");
    sem_post(&sem_cpu);
    sem_wait(&sem_ram);
    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("islemci", "Ram");

    thread_tamam("Islemci");
    return NULL;
}


static void *sogutma_thread(void *arg)
{
    (void)arg;
    sem_wait(&sem_cpu);
    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("sogutma", "Termal macun");
    

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("sogutma", "Fan");

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("sogutma", "Sivi pompasi");
    sem_post(&sem_pompa);

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("sogutma", "Sivi hortumu");

    thread_tamam("Sogutma");
    return NULL;
}

static void *depolama_thread(void *arg)
{
    (void)arg;
    
    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("depolama", "Ssd");

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("depolama", "Hdd");
    
    sem_wait(&sem_pompa);
    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("depolama", "Sata kablosu");
    sem_post(&sem_sata);
    thread_tamam("Depolama");
    return NULL;
}

static void *goruntu_thread(void *arg)
{
    (void)arg;
    
    
    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("goruntu", "Ekran karti");
    
    sem_post(&sem_ram); 
    sem_wait(&sem_sata); 
    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("goruntu", "Monitor kablosu");
    sem_post(&sem_son);
    thread_tamam("Goruntu");
    return NULL;
}

int main(void)
{
    pthread_t t_islemci, t_sogutma, t_depolama, t_goruntu;
    int rc;

    /* =================================================================
     * [TODO #2] SENKRONIZASYON DEGISKENLERINI BASLATIN (init)
     * Or: sem_init(...), pthread_mutex_init(...), pthread_cond_init(...)
     * ================================================================= */

    /* TODO: init */
    sem_init(&sem_cpu, 0, 0);
    sem_init(&sem_pompa, 0, 0);
    sem_init(&sem_sata, 0, 0);
    sem_init(&sem_ram, 0, 0);
    sem_init(&sem_ekran, 0, 0);
    sem_init(&sem_son, 0, 0);


    /* Thread'leri olustur */
    rc = pthread_create(&t_islemci,  NULL, islemci_thread,  NULL);
    if (rc) { fprintf(stderr, "pthread_create islemci: %s\n",  strerror(rc)); return EXIT_FAILURE; }

    rc = pthread_create(&t_sogutma,  NULL, sogutma_thread,  NULL);
    if (rc) { fprintf(stderr, "pthread_create sogutma: %s\n",  strerror(rc)); return EXIT_FAILURE; }

    rc = pthread_create(&t_depolama, NULL, depolama_thread, NULL);
    if (rc) { fprintf(stderr, "pthread_create depolama: %s\n", strerror(rc)); return EXIT_FAILURE; }

    rc = pthread_create(&t_goruntu,  NULL, goruntu_thread,  NULL);
    if (rc) { fprintf(stderr, "pthread_create goruntu: %s\n",  strerror(rc)); return EXIT_FAILURE; }

    /* Thread'lerin bitmesini bekle */
    pthread_join(t_islemci,  NULL);
    pthread_join(t_sogutma,  NULL);
    pthread_join(t_depolama, NULL);
    pthread_join(t_goruntu,  NULL);

    /* =================================================================
     * [TODO #3] TUM SENKRONIZASYON DEGISKENLERINI YOK EDIN (destroy)
     * Or: sem_destroy(...), pthread_mutex_destroy(...), pthread_cond_destroy(...)
     * ================================================================= */

    /* TODO: destroy */
    sem_destroy(&sem_cpu);
    sem_destroy(&sem_pompa);
    sem_destroy(&sem_sata);
    sem_destroy(&sem_ram);
    sem_destroy(&sem_ekran);
    sem_destroy(&sem_son);


    pthread_mutex_destroy(&g_yazdir_mutex);
    return EXIT_SUCCESS;
}