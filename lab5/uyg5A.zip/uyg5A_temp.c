#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>   /* sem_t kullanmayi tercih ederseniz */
#include <errno.h>

/* =====================================================================
 * SABITLER
 * ===================================================================== */
#define TOPLAM_OGE   11   /* 2 + 4 + 3 + 2 */
#define THREAD_SAYI   4

/* =====================================================================
 * GLOBAL DURUM (sira sayaci ve cikti kilidi)
 *
 * NOT: g_yazdir_mutex YALNIZCA cikti butunlugu icindir
 *      (printf'lerin satir bazinda parcalanmamasi). Senaryonun
 *      senkronizasyonunun bir parcasi DEGILDIR; "minimum senkronizasyon
 *      degiskeni" sayimina dahil edilmemelidir.
 * ===================================================================== */
static int             g_sira          = 0;
static pthread_mutex_t g_yazdir_mutex  = PTHREAD_MUTEX_INITIALIZER;

/* =====================================================================
 * [TODO #1] SENKRONIZASYON DEGISKENLERINIZ
 *
 * Asagiya kullanmak istediginiz senkronizasyon yapilarini tanimlayin.
 * (sem_t, pthread_mutex_t, pthread_cond_t, pthread_barrier_t, ...)
 *
 * Senkronizasyon kosullari (hatirlatma):
 *   - Termal macun, cpu'dan once surulemez.
 *   - Sata kablosu, sivi pompasi'ndan sonra baglanir.
 *   - Ekran karti, sata kablosu'ndan once takilir, ram'den once takilamaz.
 *   - En son monitor kablosu baglanir.
 * ===================================================================== */

/* TODO: senkronizasyon degiskenleri */


/* =====================================================================
 * YARDIMCI CIKTI FONKSIYONLARI
 *
 * Bu fonksiyonlari oldugu gibi kullanabilirsiniz. Sira sayacini ve
 * cikti formatini sizin icin yonetirler:
 *   - Ilk ogede   : "0. --> Haydi baslayalim..."
 *   - Yari gecince: "--> Kalan oge sayisi: N"
 *   - Son ogede   : "--> Hazirim..."
 * ===================================================================== */
static void oge_yazdir(const char *thread_adi, const char *oge_adi)
{
    pthread_mutex_lock(&g_yazdir_mutex);

    g_sira++;
    int sira  = g_sira;
    int kalan = TOPLAM_OGE - sira;

    if (sira == 1) {
        printf("0.\t--> Haydi baslayalim...\n");
    }

    printf("%2d. (%s) %s", sira, thread_adi, oge_adi);

    if (sira == TOPLAM_OGE) {
        printf("\t--> Hazirim...");
    } else if (sira * 2 > TOPLAM_OGE) {
        /* Sira > TOPLAM_OGE/2 olunca, yani yarisindan fazlasi tamamlaninca */
        printf("\t--> Kalan oge sayisi: %d", kalan);
    }

    printf("\n");
    fflush(stdout);

    pthread_mutex_unlock(&g_yazdir_mutex);
}

/* Bir thread kendi alt islemlerini bitirdiginde cagrilmalidir. */
static void thread_tamam(const char *thread_adi)
{
    pthread_mutex_lock(&g_yazdir_mutex);
    printf("    --> %s tamam\n", thread_adi);
    fflush(stdout);
    pthread_mutex_unlock(&g_yazdir_mutex);
}

/* =====================================================================
 * THREAD FONKSIYONLARI
 *
 * Her thread'in kendi icindeki sira SABITTIR (degistirmeyin).
 * Senkronizasyon icin gereken bekleme/sinyal cagrilarini "TODO"
 * yorumlarinin oldugu yerlere ekleyiniz.
 * ===================================================================== */

static void *islemci_thread(void *arg)
{
    (void)arg;

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("islemci", "Cpu");

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("islemci", "Ram");

    thread_tamam("Islemci");
    return NULL;
}

static void *sogutma_thread(void *arg)
{
    (void)arg;

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("sogutma", "Termal macun");

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("sogutma", "Fan");

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("sogutma", "Sivi pompasi");

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("sogutma", "Sivi hortumu");

    thread_tamam("Sogutma");
    return NULL;
}

static void *depolama_thread(void *arg)
{
    (void)arg;

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("depolama", "Ssd");

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("depolama", "Hdd");

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("depolama", "Sata kablosu");

    thread_tamam("Depolama");
    return NULL;
}

static void *goruntu_thread(void *arg)
{
    (void)arg;

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("goruntu", "Ekran karti");

    /* TODO: senkronizasyon (gerekiyorsa) */
    oge_yazdir("goruntu", "Monitor kablosu");

    thread_tamam("Goruntu");
    return NULL;
}

/* =====================================================================
 * MAIN
 * ===================================================================== */
int main(void)
{
    pthread_t t_islemci, t_sogutma, t_depolama, t_goruntu;
    int rc;

    /* =================================================================
     * [TODO #2] SENKRONIZASYON DEGISKENLERINI BASLATIN (init)
     * Or: sem_init(...), pthread_mutex_init(...), pthread_cond_init(...)
     * ================================================================= */

    /* TODO: init */


    /* Thread'leri olustur */
    rc = pthread_create(&t_islemci,  NULL, islemci_thread,  NULL);
    if (rc) { fprintf(stderr, "pthread_create islemci: %s\n",  strerror(rc)); return EXIT_FAILURE; }

    rc = pthread_create(&t_sogutma,  NULL, sogutma_thread,  NULL);
    if (rc) { fprintf(stderr, "pthread_create sogutma: %s\n",  strerror(rc)); return EXIT_FAILURE; }

    rc = pthread_create(&t_depolama, NULL, depolama_thread, NULL);
    if (rc) { fprintf(stderr, "pthread_create depolama: %s\n", strerror(rc)); return EXIT_FAILURE; }

    rc = pthread_create(&t_goruntu,  NULL, goruntu_thread,  NULL);
    if (rc) { fprintf(stderr, "pthread_create goruntu: %s\n",  strerror(rc)); return EXIT_FAILURE; }

    /* Thread'lerin bitmesini bekle */
    pthread_join(t_islemci,  NULL);
    pthread_join(t_sogutma,  NULL);
    pthread_join(t_depolama, NULL);
    pthread_join(t_goruntu,  NULL);

    /* =================================================================
     * [TODO #3] TUM SENKRONIZASYON DEGISKENLERINI YOK EDIN (destroy)
     * Or: sem_destroy(...), pthread_mutex_destroy(...), pthread_cond_destroy(...)
     * ================================================================= */

    /* TODO: destroy */


    pthread_mutex_destroy(&g_yazdir_mutex);
    return EXIT_SUCCESS;
}