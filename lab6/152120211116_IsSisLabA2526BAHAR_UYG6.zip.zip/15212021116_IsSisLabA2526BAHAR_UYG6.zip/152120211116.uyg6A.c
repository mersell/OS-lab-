#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <setjmp.h>

// sınır değişkenlerini dışarıdan alıyoruz 
extern int etext, end; 

sigjmp_buf env;

// Hata olduğunda programın patlamasını engelleyen  fonksiyon
void handle_segfault(int sig) {
    printf(" -> HATA: Bu adrese erişim yasak! (Seg Fault)\n");
    siglongjmp(env, 1); 
}

int main() {
    // Çökme durumunu yakalamak için sinyal kontrolünü açıyoruz
    signal(SIGSEGV, handle_segfault);

    /* 1. CODE SEGMENT: 
       Programın makine kodlarının durduğu yer. Sadece okunabilir (Read-Only). 
       &etext bu kısmın bittiği adrestir. */
    void* text_sonu = (void*)&etext;

    /* 2. GLOBAL (DATA)SEGMENT: 
       Global değişkenlerin saklandığı bölge. 6Code segmentınden sonra baslar. Hem okunur hem yazılır. 
       &end bu bölgenin bittiği yeri gösterir. */
    void* global_sonu = (void*)&end;

    /* 3. HEAP SEGMENT: 
       Dinamik bellek alanı. malloc ile yer açılır, sbrk(0) ile sınırı ölçülür. 
       Yukarı (yüksek adreslere) doğru büyür.  */
    int *heap_ornek = (int *)malloc(sizeof(int));
    void* heap_siniri = sbrk(0);

    /* 4. STACK SEGMENT: 
       Yerel değişkenlerin ve fonksiyonların bölgesi. Belleğin en tepesinden 
       aşağı doğru büyür.  */
    int stack_degiskeni = 100;

    printf("--- Bellek Segmentleri ve Sınır Adresleri ---\n");
    printf("code Segment Sonu (&etext): %p\n", text_sonu);
    printf("Global(data) Segment Sonu (&end): %p\n", global_sonu);
    printf("Heap Mevcut Sınırı (sbrk):  %p\n", heap_siniri);
    printf("Stack (Yerel Değişken):     %p\n\n", &stack_degiskeni);

    // --- ERİŞİM TESTLERİ ---

    // TEST 1: Globals Segmenti (Yazılabilir mi?)
    printf("1. Globals Testi: ");
    if (sigsetjmp(env, 1) == 0) {
        int *p = (int *)global_sonu - 1; 
        int okunan = *p; // Okuma
        *p = okunan;     // Yazma (Başarılı olması lazım)
        printf("OK (Hem okunur hem yazılır)\n");
    }

    // TEST 2: code Segmenti (Yazılabilir mi?)
    printf("2. code Testi:    ");
    if (sigsetjmp(env, 1) == 0) {
        char *p = (char *)text_sonu - 10;
        char okunan = *p; 
        printf("Okuma OK, Yazma deneniyor...");
        *p = 'X'; // Yazma (HATA tetikleyecektir çünkü Read-Only) 
    }

    // TEST 3: Geçersiz Bölge (NULL)
    printf("3. NULL Testi:    ");
    if (sigsetjmp(env, 1) == 0) {
        int *p = NULL;
        int okunan = *p; // Okuma (HATA tetikler, 0 adresi yasaktır)
    }

    free(heap_ornek);
    printf("\nDeney bitti. Sonuçlar gözlemlendi.\n");
    return 0;
}